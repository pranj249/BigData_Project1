package com.packa;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerTask extends Reducer<Text,Text,Text,Text> {
public void reduce(Text key,Iterable<Text> value,Context context) throws IOException, InterruptedException{
	int sum=0;
	Pattern p=Pattern.compile("\\d+");
	Matcher m=p.matcher(key.toString());
	if(m.matches()){
	for (Text text : value) {
		sum +=1;
	}
	
	context.write(key, new Text(String.valueOf(sum)));
	}
}
}
