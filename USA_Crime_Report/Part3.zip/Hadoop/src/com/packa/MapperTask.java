package com.packa;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MapperTask extends Mapper<LongWritable,Text,Text,Text>{
	static boolean flag=true;
public void map(LongWritable map,Text value,Context context) throws IOException, InterruptedException{
	
	try{
		String str=value.toString();
		String strarr=str.split(",")[5];
		String distrcit=str.split(",")[11];
		if(strarr.equalsIgnoreCase("THEFT"))
			context.write(new Text(distrcit), new Text(strarr));
	}catch(ArrayIndexOutOfBoundsException e){
		
	}
	
}
}
	