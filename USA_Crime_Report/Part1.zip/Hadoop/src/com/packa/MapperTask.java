package com.packa;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MapperTask extends Mapper<LongWritable,Text,Text,Text>{
	static boolean flag=true;
public void map(LongWritable map,Text value,Context context) throws IOException, InterruptedException{
	String str=value.toString();
	//String strarr=str.split(",")[13];
	try{
	context.write(new Text(str.split(",")[13]), new Text(str.split(",")[1]));
	}catch(ArrayIndexOutOfBoundsException e){
		
	}
	
}
}
	