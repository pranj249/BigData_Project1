package com.packa;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MapperTask extends Mapper<LongWritable,Text,Text,Text>{
	static boolean flag=true;
public void map(LongWritable map,Text value,Context context) throws IOException, InterruptedException{
	
	try{
		DateTimeFormatter  sdFormatter=DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss a");
		
				String[] str=value.toString().split(",");
				LocalDateTime time= LocalDateTime.parse(str[2], sdFormatter);
		
		if(((time.getMonthValue()>=10 && time.getYear()==2014) ||(time.getMonthValue()<10 && time.getYear()==2015))
				&& str[8].equalsIgnoreCase("true") )
			context.write(new Text("1"),new Text("1"));
	}catch(ArrayIndexOutOfBoundsException | DateTimeParseException e){
		
	}
	
}
}
	