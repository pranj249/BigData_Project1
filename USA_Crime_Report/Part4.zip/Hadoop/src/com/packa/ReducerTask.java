package com.packa;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerTask extends Reducer<Text,Text,Text,Text> {
public void reduce(Text key,Iterable<Text> value,Context context) throws IOException, InterruptedException{
	int sum=0;
	
	for (Text text : value) {
		sum +=1;
	}
	
	context.write(new Text("Arrest between Oct 2014 to Oct 2015"), new Text(String.valueOf(sum)));
	
}
}
